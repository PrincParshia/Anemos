package princ.anemos.util;

import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1309;
import net.minecraft.class_310;
import net.minecraft.class_6880;

public class MobEffectUtil {
    public static boolean hasEffect(class_6880<class_1291> holder) {
        class_1309 entity = class_310.method_1551().field_1724;
        if (entity != null) {
            for (class_1293 mobEffectInstance : entity.method_6026()) {
                if (mobEffectInstance.method_5579() == holder) {
                    return true;
                }
            }
        }
        return false;
    }
}
