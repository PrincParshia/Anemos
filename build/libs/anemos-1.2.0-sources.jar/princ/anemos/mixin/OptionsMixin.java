package princ.anemos.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2561;
import net.minecraft.class_315;
import net.minecraft.class_7172;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import princ.anemos.client.OptionInstanceImpl.UnitDouble;
import princ.anemos.util.UnitValueConverter;

import static net.minecraft.class_315.method_41782;
import static princ.anemos.AnemosConstants.*;
import static princ.anemos.util.UnitValueConverter.*;

@Mixin(class_315.class)
@Environment(EnvType.CLIENT)
public class OptionsMixin {
    @Shadow
    @Final
    @Mutable
    private class_7172<Double> gamma;

    @Redirect(method = "<init>", at = @At(value = "FIELD", target = "Lnet/minecraft/client/Options;gamma:Lnet/minecraft/client/OptionInstance;"))
    public void init(class_315 options, class_7172<?> instance) {
        this.gamma = new class_7172<>("options.gamma", class_7172.method_42399(), (component, double_) -> {
            int i = (int) (double_ * (double) 100.0F);
            if (i == toPercent((int) configInternal.gamma.min)) {
                return method_41783(component, class_2561.method_43471("options.gamma.min"));
            } else if (i == config.gamma.defaultValue.get().intValue()) {
                return method_41783(component, class_2561.method_43471("options.gamma.default"));
            } else {
                return i == toPercent((int) configInternal.gamma.max) ? method_41783(component, class_2561.method_43471("options.gamma.max")) : method_41782(component, i);
            }
        }, UnitDouble.INSTANCE, UnitValueConverter.fromPercent(config.gamma.defaultValue.get()), (double_) -> {
        });
    }
}