package princ.anemos.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1291;
import net.minecraft.class_1294;
import net.minecraft.class_1309;
import net.minecraft.class_6880;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import static princ.anemos.AnemosConstants.*;

@Mixin(class_1309.class)
@Environment(EnvType.CLIENT)
public class LivingEntityMixin {
    @Inject(method = "hasEffect", at = @At("HEAD"), cancellable = true)
    public void fakeHasEffect(class_6880<class_1291> holder, CallbackInfoReturnable<Boolean> cir) {
        if (holder == class_1294.field_5925 && config.fakeNightVision.enabled.get()) {
            cir.setReturnValue(true);
        } else if (holder == class_1294.field_5919 && config.removeBlindness.enabled.get()) {
            cir.setReturnValue(false);
        } else if (holder == class_1294.field_38092 && config.removeDarkness.enabled.get()) {
            cir.setReturnValue(false);
        }
    }
}