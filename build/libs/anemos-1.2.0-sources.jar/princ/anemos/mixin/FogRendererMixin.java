package princ.anemos.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1294;
import net.minecraft.class_1309;
import net.minecraft.class_4184;
import net.minecraft.class_638;
import net.minecraft.class_757;
import net.minecraft.class_758;
import org.joml.Vector4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import static princ.anemos.AnemosConstants.*;
import static princ.anemos.util.MobEffectUtil.*;

@Mixin(class_758.class)
@Environment(EnvType.CLIENT)
public class FogRendererMixin {
    @Inject(method = "computeFogColor", at = @At("HEAD"), cancellable = true)
    private void computeFogColor(class_4184 camera, float f, class_638 clientLevel, int i, float g, boolean bl, CallbackInfoReturnable<Vector4f> cir) {
        if ((hasEffect(class_1294.field_5919) && config.removeBlindness.enabled.get()) || (hasEffect(class_1294.field_38092) && config.removeDarkness.enabled.get())) {
            cir.setReturnValue(new Vector4f(0.0F, 0.0F, 0.0F, 1.0F));
        }
    }

    @Redirect(method = "computeFogColor", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/GameRenderer;getNightVisionScale(Lnet/minecraft/world/entity/LivingEntity;F)F"))
    private static float redirectNightVisionFogColor(class_1309 livingEntity, float f) {
        if (config.fakeNightVision.enabled.get() && !config.fakeNightVision.fog) {
            return 0.0F;
        }
        return class_757.method_3174(livingEntity, f);
    }
}
