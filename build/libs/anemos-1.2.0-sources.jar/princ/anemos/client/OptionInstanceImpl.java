package princ.anemos.client;

import com.mojang.serialization.Codec;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_7172.class_7176;
import java.util.Objects;
import java.util.Optional;
import java.util.function.DoubleFunction;
import java.util.function.ToDoubleFunction;

import static princ.anemos.AnemosConstants.*;

@Environment(EnvType.CLIENT)
public class OptionInstanceImpl {
    @Environment(EnvType.CLIENT)
    public enum UnitDouble implements class_7176<Double> {
        INSTANCE;

        @Override
        public Optional<Double> validateValue(Double double_) {
            return double_ >= configInternal.gamma.min && double_ <= configInternal.gamma.max ? Optional.of(double_) : Optional.empty();
        }

        @Override
        public double toSliderValue(Double double_) {
            return (double_ - configInternal.gamma.min) / (configInternal.gamma.max - configInternal.gamma.min);
        }

        @Override
        public Double method_41763(double d) {
            return d * (configInternal.gamma.max - configInternal.gamma.min) + configInternal.gamma.min;
        }

        public <R> class_7176<R> xmap(final DoubleFunction<? extends R> doubleFunction, final ToDoubleFunction<? super R> toDoubleFunction) {
            return new class_7176<R>() {
                public Optional<R> method_41758(R object) {
                    Objects.requireNonNull(doubleFunction);
                    return UnitDouble.this.validateValue(toDoubleFunction.applyAsDouble(object)).map(doubleFunction::apply);
                }

                public double method_41765(R object) {
                    return OptionInstanceImpl.UnitDouble.this.toSliderValue(toDoubleFunction.applyAsDouble(object));
                }

                public R method_41763(double d) {
                    return (R) doubleFunction.apply(OptionInstanceImpl.UnitDouble.this.method_41763(d));
                }

                public Codec<R> comp_675() {
                    Objects.requireNonNull(toDoubleFunction);
                    return UnitDouble.this.comp_675().xmap(doubleFunction::apply, toDoubleFunction::applyAsDouble);
                }
            };
        }

        @Override
        public Codec<Double> comp_675() {
            return Codec.withAlternative(Codec.doubleRange(configInternal.gamma.min, configInternal.gamma.max), Codec.BOOL, (boolean_) -> boolean_ ? configInternal.gamma.max : configInternal.gamma.min);
        }
    }
}
