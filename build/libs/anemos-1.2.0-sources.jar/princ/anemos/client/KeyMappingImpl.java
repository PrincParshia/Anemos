package princ.anemos.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_304;
import net.minecraft.class_3675;

import static princ.anemos.AnemosConstants.*;

@Environment(EnvType.CLIENT)
public class KeyMappingImpl {
    public static final class_304 gammaKey = new class_304(GENERIC_KEY_NAMESPACE + ".gamma", class_3675.class_307.field_1668, class_3675.field_32021, KEY_CATEGORY);
    public static final class_304 fakeNightVisionKey = new class_304(GENERIC_KEY_NAMESPACE + ".fnv", class_3675.class_307.field_1668, class_3675.field_32028, KEY_CATEGORY);
    public static final class_304 removeBlindnessKey = new class_304(GENERIC_KEY_NAMESPACE + ".rmb", class_3675.class_307.field_1668, class_3675.field_32016, KEY_CATEGORY);
    public static final class_304 removeDarknessKey = new class_304(GENERIC_KEY_NAMESPACE + ".rmd", class_3675.class_307.field_1668, class_3675.field_32027, KEY_CATEGORY);

    public static void registerMappings() {
        KeyBindingHelper.registerKeyBinding(gammaKey);
        ClientTickEvents.END_CLIENT_TICK.register(minecraft -> {
            if (gammaKey.method_1436()) adjustGamma(config.gamma.transition);
            handleGammaTransition();
        });

        KeyBindingHelper.registerKeyBinding(fakeNightVisionKey);
        ClientTickEvents.END_CLIENT_TICK.register(minecraft -> {
            adjustFakeNightVision();
            if (fakeNightVisionKey.method_1436()) adjustFakeNightVisionScale(config.fakeNightVision.transition);
            handleFakeNightVisionScaleTransition();
        });

        KeyBindingHelper.registerKeyBinding(removeBlindnessKey);
        ClientTickEvents.END_CLIENT_TICK.register(minecraft -> {
            if (removeBlindnessKey.method_1436()) adjustRemoveBlindness(config.removeBlindness.transition);
            handleRemoveBlindnessTransition();
        });

        KeyBindingHelper.registerKeyBinding(removeDarknessKey);
        ClientTickEvents.END_CLIENT_TICK.register(minecraft -> {
            if (removeDarknessKey.method_1436()) adjustRemoveDarkness(config.removeDarkness.transition);
            handleRemoveDarknessTransition();
        });
    }
}
