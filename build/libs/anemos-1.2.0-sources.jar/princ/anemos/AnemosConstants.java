package princ.anemos;

import me.fzzyhmstrs.fzzy_config.api.ConfigApiJava;
import me.fzzyhmstrs.fzzy_config.api.RegisterType;
import me.fzzyhmstrs.fzzy_config.validation.number.ValidatedFloat;
import net.minecraft.class_1294;
import net.minecraft.class_310;
import net.minecraft.class_5819;
import net.minecraft.class_7172;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import princ.anemos.config.AnemosConfig;
import princ.anemos.config.AnemosConfigInternal;
import princ.anemos.util.UnitValueConverter;

import static princ.anemos.util.MobEffectUtil.*;

public class AnemosConstants {
    public static final String NAMESPACE = "anemos";
    public static final String NAME = "Anemos";
    public static final Logger LOGGER = LoggerFactory.getLogger(NAME);
    public static final String KEY_CATEGORY = "key.categories." + NAMESPACE;
    public static final String GENERIC_KEY_NAMESPACE = "key." + NAMESPACE;
    public static final String GENERIC_CONFIG_TRANSLATION_PREFIX = "config." + NAMESPACE;
    public static final AnemosConfig config = ConfigApiJava.registerAndLoadConfig(AnemosConfig::new, RegisterType.CLIENT);
    public static final AnemosConfigInternal configInternal = ConfigApiJava.registerAndLoadConfig(AnemosConfigInternal::new, RegisterType.SERVER);

    public static class_7172<Double> gamma() {
        return class_310.method_1551().field_1690.method_42473();
    }

    public static ValidatedFloat fnvScale() {
        return config.fakeNightVision.scale;
    }

    private static int gammaTransitionTime;
    private static double targetGamma;
    private static int elapsedGammaTransitionTime;
    private static boolean execGammaTransition;

    public static void adjustGamma(boolean transition) {
        if (transition) {
            if (!execGammaTransition) {
                targetGamma = gamma().method_41753() != UnitValueConverter.fromPercent(config.gamma.toggleValue.get()) ? UnitValueConverter.fromPercent(config.gamma.toggleValue.get()) : UnitValueConverter.fromPercent(configInternal.gamma.prev.get());
                if (targetGamma == UnitValueConverter.fromPercent(config.gamma.toggleValue.get())) configInternal.gamma.prev.validateAndSet(UnitValueConverter.toPercent(gamma().method_41753()));
                gammaTransitionTime = config.gamma.transitionTime;
                elapsedGammaTransitionTime = 0;
                execGammaTransition = true;
            } else {
                targetGamma = targetGamma != UnitValueConverter.fromPercent(config.gamma.toggleValue.get()) ? UnitValueConverter.fromPercent(config.gamma.toggleValue.get()) : UnitValueConverter.fromPercent(configInternal.gamma.prev.get());
                gammaTransitionTime = elapsedGammaTransitionTime;
                elapsedGammaTransitionTime = 0;
            }
        } else {
            targetGamma = gamma().method_41753() != UnitValueConverter.fromPercent(config.gamma.toggleValue.get()) ? UnitValueConverter.fromPercent(config.gamma.toggleValue.get()) : UnitValueConverter.fromPercent(configInternal.gamma.prev.get());
            if (targetGamma == UnitValueConverter.fromPercent(config.gamma.toggleValue.get())) configInternal.gamma.prev.validateAndSet(UnitValueConverter.toPercent(gamma().method_41753()));
            gamma().method_41748(targetGamma);
            config.save();
            configInternal.save();
        }
    }

    public static void handleGammaTransition() {
        if (config.gamma.transition && execGammaTransition) {
            if (gammaTransitionTime <= 0) {
                execGammaTransition = false;
                config.save();
                configInternal.save();
            } else {
                gamma().method_41748(gamma().method_41753() + ((targetGamma - gamma().method_41753()) / gammaTransitionTime));
                gammaTransitionTime--;
                elapsedGammaTransitionTime++;
            }
        }
    }

    private static boolean wasFakeNightVision;

    public static void adjustFakeNightVision() {
        if (fnvScale().get() == configInternal.fakeNightVision.minScale) {
            config.fakeNightVision.enabled.validateAndSet(false);
        }

        if (!config.fakeNightVision.fog) {
            if (hasEffect(class_1294.field_5925) && config.fakeNightVision.enabled.get()) {
                adjustFakeNightVisionScale(config.fakeNightVision.transition);
                wasFakeNightVision = true;
            }

            if (!hasEffect(class_1294.field_5925) && wasFakeNightVision) {
                adjustFakeNightVisionScale(config.fakeNightVision.transition);
                wasFakeNightVision = false;
            }
        }
    }

    private static int fnvTransitionTime;
    private static float targetFnvScale;
    private static int elapsedFnvTransitionTime;
    private static boolean execFnvTransition;

    public static void adjustFakeNightVisionScale(boolean transition) {
        if (transition) {
            if (!execFnvTransition) {
                if (!config.fakeNightVision.enabled.get()) {
                    targetFnvScale = UnitValueConverter.fromPercent(fnvScale().get());
                    fnvScale().validateAndSet(UnitValueConverter.fromPercent(configInternal.fakeNightVision.minScale));
                    config.fakeNightVision.enabled.validateAndSet(true);
                } else {
                    targetFnvScale = UnitValueConverter.fromPercent(configInternal.fakeNightVision.minScale);
                    configInternal.fakeNightVision.prev.validateAndSet(fnvScale().get());
                }

                fnvTransitionTime = config.fakeNightVision.transitionTime;
                elapsedFnvTransitionTime = 0;
                execFnvTransition = true;
            } else {
                targetFnvScale = targetFnvScale != UnitValueConverter.fromPercent(configInternal.fakeNightVision.minScale) ? UnitValueConverter.fromPercent(configInternal.fakeNightVision.minScale) : UnitValueConverter.fromPercent(configInternal.fakeNightVision.prev.get());
                fnvTransitionTime = elapsedFnvTransitionTime;
                elapsedFnvTransitionTime = 0;
            }
        } else {
            config.fakeNightVision.enabled.validateAndSet(!config.fakeNightVision.enabled.get());
            config.save();
        }
    }

    public static void handleFakeNightVisionScaleTransition() {
        if (config.fakeNightVision.transition && execFnvTransition) {
            if (fnvTransitionTime <= 0) {
                execFnvTransition = false;
                if (targetFnvScale == UnitValueConverter.fromPercent(configInternal.fakeNightVision.minScale)) {
                    fnvScale().validateAndSet(configInternal.fakeNightVision.prev.get());
                }
                config.save();
                configInternal.save();
            } else {
                fnvScale().validateAndSet(UnitValueConverter.toPercent(UnitValueConverter.fromPercent(fnvScale().get()) + ((targetFnvScale - UnitValueConverter.fromPercent(fnvScale().get())) / fnvTransitionTime)));
                fnvTransitionTime--;
                elapsedFnvTransitionTime++;
            }
        }
    }

    private static final class_5819 random = class_5819.method_43047();

    private static int rmbTransitionTime;
    private static int rmbTransitionDuration;
    private static boolean execRmbTransition;
    private static boolean targetRmbState;

    public static void adjustRemoveBlindness(boolean transition) {
        if (transition) {
            if (!execRmbTransition) {
                targetRmbState = !config.removeBlindness.enabled.get();
                rmbTransitionTime = 0;
                rmbTransitionDuration = config.removeBlindness.transitionTime + random.method_43048(10);
                execRmbTransition = true;
            }
        } else {
            config.removeBlindness.enabled.validateAndSet(!config.removeBlindness.enabled.get());
            config.save();
        }
    }

    public static void handleRemoveBlindnessTransition() {
        if (config.removeBlindness.transition && execRmbTransition) {
            rmbTransitionTime++;

            if (random.method_43057() < (1.0F - ((float) rmbTransitionTime / rmbTransitionDuration))) {
                config.removeBlindness.enabled.validateAndSet(!config.removeBlindness.enabled.get());
            }

            if (rmbTransitionTime >= rmbTransitionDuration) {
                config.removeBlindness.enabled.validateAndSet(targetRmbState);
                execRmbTransition = false;
                config.save();
            }
        }
    }

    private static int rmdTransitionTime;
    private static int rmdTransitionDuration;
    private static boolean execRmdTransition;
    private static boolean targetRmdState;

    public static void adjustRemoveDarkness(boolean transition) {
        if (transition) {
            if (!execRmdTransition) {
                targetRmdState = !config.removeDarkness.enabled.get();
                rmdTransitionTime = 0;
                rmdTransitionDuration = config.removeDarkness.transitionTime + random.method_43048(10);
                execRmdTransition = true;
            }
        } else {
            config.removeDarkness.enabled.validateAndSet(!config.removeDarkness.enabled.get());
            config.save();
        }
    }

    public static void handleRemoveDarknessTransition() {
        if (config.removeDarkness.transition && execRmdTransition) {
            rmdTransitionTime++;

            if (random.method_43057() < (1.0F - ((float) rmdTransitionTime / rmdTransitionDuration))) {
                config.removeDarkness.enabled.validateAndSet(!config.removeDarkness.enabled.get());
            }

            if (rmdTransitionTime >= rmdTransitionDuration) {
                config.removeDarkness.enabled.validateAndSet(targetRmdState);
                execRmdTransition = false;
                config.save();
            }
        }
    }
}